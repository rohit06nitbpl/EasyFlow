#!python

print "hi form EasyFlow/bin/test.py"
