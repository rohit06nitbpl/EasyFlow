class DataExtractor:
    def __init__(self):
        pass

    def get_generator(self):
        raise NotImplementedError('Not implemented')
    